#' PROJ
#' @export PROJ
PROJ <- new.env(parent = emptyenv())
