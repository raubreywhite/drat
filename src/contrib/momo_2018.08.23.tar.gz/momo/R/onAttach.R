.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: momo')
  packageStartupMessage('Version 2018.08.23')
}
