#' PROJ
#' @export PROJ
PROJ <- new.env(parent = emptyenv())

#' CONFIG
CONFIG <- new.env(parent = emptyenv())
CONFIG$ALLOW_FILE_MANIPULATION_FROM_INITIALISE_PROJECT <- FALSE
