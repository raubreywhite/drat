.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2019.02.21 at 08:43")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
