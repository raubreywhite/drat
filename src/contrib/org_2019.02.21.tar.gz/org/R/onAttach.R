.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: org')
  packageStartupMessage('Version: x')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
