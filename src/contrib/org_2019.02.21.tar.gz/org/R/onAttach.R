.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2019.02.21 at 07:59")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
