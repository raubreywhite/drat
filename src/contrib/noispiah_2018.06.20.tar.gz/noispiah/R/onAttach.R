.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: noispiah')
  packageStartupMessage('Version 2018.06.20')
  packageStartupMessage('Developed by Richard White')
  packageStartupMessage('Department of Infectious Disease Epidemiology and Modelling')
  packageStartupMessage('Norwegian Institute of Public Health')
}
