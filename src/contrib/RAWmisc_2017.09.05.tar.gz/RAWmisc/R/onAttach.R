.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: RAWmisc')
  packageStartupMessage('Version 2017.09.05')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
