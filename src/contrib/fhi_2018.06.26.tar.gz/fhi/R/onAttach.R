.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: FHI')
  packageStartupMessage('Version 2018.06.26')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
