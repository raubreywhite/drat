.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2019.03.05 at 06:01")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
