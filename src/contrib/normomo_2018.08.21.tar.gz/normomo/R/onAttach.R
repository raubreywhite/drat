.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: normomo')
  packageStartupMessage('Version 2018.08.21')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
