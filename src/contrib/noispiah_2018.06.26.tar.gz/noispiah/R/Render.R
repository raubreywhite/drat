#' RenderExternally
#' @param input a
#' @param output_file a
#' @param output_dir a
#' @param params a
#' @importFrom processx run
#' @export RenderExternally
RenderExternally <- function(input, output_file, output_dir, params="x=1"){
  tmp_dir <- tempdir()
  tmp_name <- "temptemp.pdf"

  numberFails <- 0
  succeed <- FALSE
  while(numberFails < 3 & succeed==FALSE){
    x <- processx::run(
      command='R',
      args=c(
        '-e',
        sprintf('rmarkdown::render(\"%s\",output_file=\"%s\",output_dir=\"%s\",params=list(%s))',
                input,
                tmp_name,
                tmp_dir,
                params
        )
      ),
      error_on_status = F
    )
    if(x$status!=0){
      print(x)
      print(tmp_dir)
      print(tmp_name)
      numberFails <- numberFails + 1
      print(sprintf("FAILED %s TIMES, RETRYING",numberFails))
    } else {
      succeed <- TRUE
    }
  }
  if(succeed){
    file.copy(file.path(tmp_dir,tmp_name),file.path(output_dir,output_file))
  } else {
    stop("ERROR!!!")
  }
  #file.remove(file.path(tmp_dir,tmp_name))

  return(x)
}

#' ExtractEnglish
#' @param var a
#' @importFrom stringr str_extract_all
#' @export ExtractEnglish
ExtractEnglish <- function(var){
  unlist(lapply(stringr::str_extract_all(var,"[a-zA-Z]"),paste0,collapse=""))
}

#' Render
#' @param dev a
#' @param outputDir a
#' @param FILES_RMD_USE_SYKEHJEM a
#' @param FILES_RMD_USE_SYKEHUS a
#' @import data.table
#' @import fhi
#' @importFrom readxl read_excel
#' @importFrom rmarkdown render
#' @importFrom lubridate today
#' @export Render
Render <- function(
  dev=FALSE,
  outputDir=fhi::DashboardFolder("results"),
  FILES_RMD_USE_SYKEHJEM,
  FILES_RMD_USE_SYKEHUS
  ){

  Fylke <- NULL

  outputDirDaily <- file.path(outputDir,lubridate::today())
  dir.create(outputDirDaily)
  dir.create(file.path(outputDirDaily,"Sykehjem"))
  dir.create(file.path(outputDirDaily,"Sykehjem","Landsdekkende"))
  dir.create(file.path(outputDirDaily,"Sykehjem","Fylke"))
  dir.create(file.path(outputDirDaily,"Sykehjem","Kommune"))

  da <- data.table(readxl::read_excel(fhi::DashboardFolder("data_raw","AntibiotikadataPrimer.xlsx")))
  di <- data.table(readxl::read_excel(fhi::DashboardFolder("data_raw","InfeksjonsdataPrimer.xlsx")))

  for(location in c(
    "Landsdekkende",
    "Akershus",
    "Aust-Agder",
    "Buskerud",
    "Finnmark",
    "Hedmark",
    "Hordaland",
    "M\u00F8re og Romsdal",
    "Nordland",
    "Oppland",
    "Oslo",
    "Rogaland",
    "Sogn og Fjordane",
    "Telemark",
    "Troms",
    "Tr\u00F8ndelag",
    "Vest-Agder",
    "Vestfold",
    "\u00D8stfold")){

    print(location)

    if(location=="Landsdekkende"){
      outputDirUse <- file.path(outputDirDaily,"Sykehjem","Landsdekkende")
      level <- "landsdekkende"
    } else {
      outputDirUse <- file.path(outputDirDaily,"Sykehjem","Fylke")
      level <- "fylke"
    }
    Sys.sleep(1)
    RenderExternally(input=FILES_RMD_USE_SYKEHJEM,
                     output_file=sprintf("%s.pdf",location),
                     output_dir=outputDirUse,
                     params=sprintf("dev=\"%s\",level=\"%s\",location=\"%s\"",dev,level,location))

    useableKommune <- unique(c(da[Fylke==location]$Kommune,di[Fylke==location]$Kommune))
    if(length(useableKommune)>0){
      dir.create(file.path(outputDirDaily,"Sykehjem","Kommune",location))
      outputDirUse <- file.path(outputDirDaily,"Sykehjem","Kommune",location)
      for(k in useableKommune){
        Sys.sleep(1)
        print(sprintf("%s - %s",location,k))
        RenderExternally(input=FILES_RMD_USE_SYKEHJEM,
                         output_file=sprintf("%s.pdf",k),
                         output_dir=outputDirUse,
                         params=sprintf("dev=\"%s\",level=\"%s\",location=\"%s\"",dev,"kommune",k))
      }
    }
  }

  dir.create(file.path(outputDirDaily,"Sykehjus"))
  dir.create(file.path(outputDirDaily,"Sykehjus","Landsdekkende"))
  dir.create(file.path(outputDirDaily,"Sykehjus","Institusjon"))

  da <- data.table(readxl::read_excel(fhi::DashboardFolder("data_raw","AntibiotikadataSpesialist.xlsx")))
  di <- data.table(readxl::read_excel(fhi::DashboardFolder("data_raw","InfeksjonsdataSpesialist.xlsx")))

  for(location in c("Landsdekkende",unique(c(da$Institusjon,di$Institusjon)))){
    if(location=="Landsdekkende"){
      outputDirUse <- file.path(outputDirDaily,"Sykehjus","Landsdekkende")
      level <- "landsdekkende"
    } else {
      outputDirUse <- file.path(outputDirDaily,"Sykehjus","Institusjon")
      level <- "institusjon"
    }
    Sys.sleep(1)
    print(location)
    RenderExternally(input=FILES_RMD_USE_SYKEHUS,
                     output_file=sprintf("%s.pdf",location),
                     output_dir=outputDirUse,
                     params=sprintf("dev=\"%s\",level=\"%s\",location=\"%s\"",dev,level,location))
  }

}

