.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: RAWmisc")
  packageStartupMessage("Version ")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
