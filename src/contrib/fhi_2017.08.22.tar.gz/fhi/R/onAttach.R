.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: FHI')
  packageStartupMessage('Version 2017.08.22')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
