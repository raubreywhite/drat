.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2020.02.18 at 08:02")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
