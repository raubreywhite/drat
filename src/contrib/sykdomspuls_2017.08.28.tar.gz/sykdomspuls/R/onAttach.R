.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: sykdomspuls')
  packageStartupMessage('Version 2017.08.28')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
