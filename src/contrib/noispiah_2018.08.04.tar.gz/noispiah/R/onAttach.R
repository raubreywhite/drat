.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: noispiah')
  packageStartupMessage('Version 2018.08.04')
  packageStartupMessage('Developed by Richard White')
  packageStartupMessage('Department of Infectious Disease Epidemiology and Modelling')
  packageStartupMessage('Norwegian Institute of Public Health')
}
