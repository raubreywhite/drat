.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: org')
  packageStartupMessage('Version 2018.10.18')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
