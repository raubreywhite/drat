.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: msis')
  packageStartupMessage('Version 2017.08.01')
  packageStartupMessage('Developed by Beatriz Valcarcel, Norwegian Institute of Public Health')
}
