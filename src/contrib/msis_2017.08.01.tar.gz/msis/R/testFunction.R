#' MyNewFunction
#' This is a function
#' @param argument1 This is my parameter
#' @importFrom stats rnorm
#' @export MyNewFunction
MyNewFunction <- function(argument1){

  return(rnorm(3))
}
