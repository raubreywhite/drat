context("Testing some functions")


test_that("My first test", {
  result <- MyNewFunction2(3)
  expect_equal(result,3)
})

