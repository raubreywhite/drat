context("FormatData")


test_that("Basic Oslo", {

  expect_equal("a","a")
})

