library(testthat)
library(msis)

test_check("msis")
