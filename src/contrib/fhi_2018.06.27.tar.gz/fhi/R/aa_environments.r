#' PROJ
#' @export PROJ
PROJ <- new.env(parent = emptyenv())

#' countyToMunicip
#' @docType data
#' @name countyToMunicip
#' @usage data(countyToMunicip)
NULL
