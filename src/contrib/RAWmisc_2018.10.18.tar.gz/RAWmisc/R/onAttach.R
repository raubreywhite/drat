.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: RAWmisc')
  packageStartupMessage('Version 2018.10.18')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
