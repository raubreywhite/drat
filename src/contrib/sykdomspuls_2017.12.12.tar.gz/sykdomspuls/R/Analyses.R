#' PROJ
#' @param yearMin a
#' @param yearMax a
#' @param numPerYear1 a
#' @export CalculateTrainPredictYearPattern
CalculateTrainPredictYearPattern <- function(yearMin,yearMax,numPerYear1=1){
  perYear1 <- seq(yearMax-numPerYear1+1,yearMax,by=1)
  perYear2 <- c((yearMin+6):(yearMax-numPerYear1))
  perFixed <- c(yearMin:(yearMin+5))
  if(length(perYear2)%%2==1){
    perYear1 <- c(max(perYear2),perYear1)
    perYear2 <- perYear2[-length(perYear2)]
  }

  years <- list()
  years[[1]] <- list(
    yearTrainMin=min(perFixed),
    yearTrainMax=max(perFixed-1),
    yearPredictMin=min(perFixed),
    yearPredictMax=max(perFixed)
  )
  index <- 2
  for(i in 1:length(perYear2)){
    if(i%%2==0) next
    years[[index]] <- list(
      yearTrainMin=perYear2[i]-5,
      yearTrainMax=perYear2[i]-1,
      yearPredictMin=perYear2[i],
      yearPredictMax=perYear2[i]+1
    )
    index <- index + 1
  }
  for(i in 1:length(perYear1)){
    years[[index]] <- list(
      yearTrainMin=perYear1[i]-5,
      yearTrainMax=perYear1[i]-1,
      yearPredictMin=perYear1[i],
      yearPredictMax=perYear1[i]
    )
    index <- index + 1
  }
  return(years)
}

#' PROJ
#' @param data a
#' @param v a
#' @import data.table
#' @export AnalyseYearLine
AnalyseYearLine <- function(data,  v) {
  yearMax <- as.numeric(format.Date(max(data$date),"%G"))
  yearMin <- as.numeric(format.Date(min(data$date),"%G"))

  dataset <- data[, .(n = sum(value),
                      consult = sum(consult),
                      pop = sum(pop),
                      HelligdagIndikator=mean(HelligdagIndikator)), by = .(date)]

  years <- CalculateTrainPredictYearPattern(yearMin=yearMin, yearMax=yearMax, numPerYear1=1)
  res <- vector("list",length=length(years))

  for(i in 1:length(years)){
    dateTrainMin <- sprintf("%s-01-01",years[[i]]$yearTrainMin)
    dateTrainMax <- sprintf("%s-12-31",years[[i]]$yearTrainMax)

    datePredictMin <- sprintf("%s-01-01",years[[i]]$yearPredictMin)
    datePredictMax <- sprintf("%s-12-31",years[[i]]$yearPredictMax)

    res[[i]] <- QuasipoissonTrainPredictData(
      datasetTrain=dataset[date >= dateTrainMin & date <= dateTrainMax],
      datasetPredict=dataset[date >= datePredictMin & date <= datePredictMax],
      isDaily=F, v=v)
  }
  res <- rbindlist(res)
  res <- res[!is.na(threshold2)]

  res[week>=30,x:=week-29]
  res[week<30,x:=week+23]
  res[, wkyr := paste0(year, "-", formatC(week, flag = "0", width = 2))]

  dates <- data.table(day = seq.Date(as.Date("2000-01-01"), as.Date("2030-01-01"), by = "days"))
  dates[, wkyr := format.Date(day, format = "%G-%V")]
  dates <- dates[, .(displayDay = max(day)), by = .(wkyr)]
  res <- merge(res, dates, by = "wkyr")
  res <- res[,c("displayDay", "wkyr", "x", variablesAlgorithmWeekly, variablesAlgorithmBasic, variablesAlgorithmProduced),with=F]
  return(res)
}

#' PROJ
#' @param data a
#' @param v a
#' @import data.table
#' @export AnalyseRecentLine
AnalyseRecentLine <- function(data, v) {
  yearMax <- as.numeric(format.Date(max(data$date),"%G"))
  yearMin <- as.numeric(format.Date(min(data$date),"%G"))

  dataset <- data[, .(n = sum(value),
                                      consult = sum(consult),
                                      pop = sum(pop),
                                      HelligdagIndikator=mean(HelligdagIndikator)), by = .(date)]

  years <- CalculateTrainPredictYearPattern(yearMin=yearMin, yearMax=yearMax, numPerYear1=1)
  res <- vector("list",length=length(years))

  for(i in 1:length(years)){
    dateTrainMin <- sprintf("%s-01-01",years[[i]]$yearTrainMin)
    dateTrainMax <- sprintf("%s-12-31",years[[i]]$yearTrainMax)

    datePredictMin <- sprintf("%s-01-01",years[[i]]$yearPredictMin)
    datePredictMax <- sprintf("%s-12-31",years[[i]]$yearPredictMax)

    res[[i]] <- QuasipoissonTrainPredictData(
      datasetTrain=dataset[date >= dateTrainMin & date <= dateTrainMax],
      datasetPredict=dataset[date >= datePredictMin & date <= datePredictMax],
      isDaily=T, v=v)
  }
  res <- rbindlist(res)
  res <- res[!is.na(threshold2)]

  res <- res[,c(variablesAlgorithmDaily, variablesAlgorithmBasic, variablesAlgorithmProduced),with=F]

  return(res)
}

#' RunOneAnalysis
#' @param analysesStack a
#' @param analysisData a
#' @import data.table
#' @export RunOneAnalysis
RunOneAnalysis <- function(analysesStack,analysisData){
  #runData <- GetDataFromControlStack(analysesIter)
  if(analysesStack$type=="influensa"){
    setnames(analysisData,"consultWithInfluensa","consult")
  } else {
    setnames(analysisData,"consultWithoutInfluensa","consult")
  }

  retval <- NULL
  if(analysesStack$granularity=="Daily"){
    retval <- AnalyseRecentLine(
          data = analysisData,
          v = analysesStack$v)
  } else {
    retval <- AnalyseYearLine(
      data = analysisData,
      v = analysesStack$v)
  }

  retval[, age := analysesStack$age]
  retval[, type := analysesStack$type]
  retval[, location := analysesStack$location]
  retval[, locationName := GetLocationName(analysesStack$location, norwayLocations=norwayLocations)]

  retval[, status := "Normal"]
  retval[n > 1 & n > threshold2, status := "Medium"]
  retval[n > 1 & n > threshold4, status := "High"]
  return(retval)
}

#' PROB
#' @param location a
#' @param norwayLocations a
#' @import data.table
#' @export GetLocationName
GetLocationName <- function(location, norwayLocations) {
  locationName <- "Norge"

  if (location != "Norge") {
    if (sum(norwayLocations$municip == location) > 0) {
      locationName <- as.character(norwayLocations$municipName[norwayLocations$municip == location])
    } else if (sum(norwayLocations$county == location) > 0) {
      locationName <- as.character(norwayLocations$countyName[norwayLocations$county == location])
    }
  }

  return(locationName)
}

#' PROB
#' @param location a
#' @param norwayLocations a
#' @import data.table
#' @export GetCountyFromMunicip
GetCountyFromMunicip <- function(location, norwayLocations) {
  if (sum(norwayLocations$municip == location) > 0) {
    location <- as.character(norwayLocations$county[norwayLocations$municip == location])
  }

  return(location)
}


