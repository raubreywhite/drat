.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: sykdomspuls')
  packageStartupMessage('Version 2017.12.12')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
