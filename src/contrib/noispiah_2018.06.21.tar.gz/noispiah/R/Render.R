#' ExtractEnglish
#' @param var a
#' @importFrom stringr str_extract_all
#' @export ExtractEnglish
ExtractEnglish <- function(var){
  unlist(lapply(stringr::str_extract_all(var,"[a-zA-Z]"),paste0,collapse=""))
}

#' Render
#' @param dev a
#' @param outputDir a
#' @import data.table
#' @import fhi
#' @importFrom rmarkdown render
#' @importFrom lubridate today
#' @export Render
Render <- function(dev=FALSE,outputDir=fhi::DashboardFolder("results")){
  outputDirDaily <- file.path(outputDir,lubridate::today())
  dir.create(outputDirDaily)

  for(fylke in c(
    "Landsdekkende",
    "Akershus",
    "Aust-Agder",
    "Buskerud",
    "Finnmark",
    "Hedmark",
    "Hordaland",
    "M\u00F8re og Romsdal",
    "Nordland",
    "Oppland",
    "Oslo",
    "Rogaland",
    "Sogn og Fjordane",
    "Telemark",
    "Troms",
    "Tr\u00F8ndelag",
    "Vest-Agder",
    "Vestfold",
    "\u00D8stfold")){

    rmarkdown::render(CONFIG$FILES_RMD_USE_RAPPORT,
                      output_file = sprintf("%s.pdf",ExtractEnglish(fylke)),
                      output_dir = outputDirDaily,
                      params = list(dev = dev,fylke=fylke))
  }

}
