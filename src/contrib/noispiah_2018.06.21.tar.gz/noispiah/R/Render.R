#' Render
#' @param dev a
#' @param outputDir a
#' @import data.table
#' @import fhi
#' @importFrom rmarkdown render
#' @importFrom lubridate today
#' @export Render
Render <- function(dev=FALSE,outputDir=fhi::DashboardFolder("results")){
  outputDirDaily <- file.path(outputDir,lubridate::today())
  dir.create(outputDirDaily)

  rmarkdown::render(CONFIG$FILES_RMD_USE_LANDSDEKKENDE,
                    output_file = "landsdekkende.pdf",
                    output_dir = outputDirDaily,
                    params = list(dev = dev))

  for(fylke in c("Akershus",
                 "Aust-Agder",
                 "Buskerud",
                 "Finnmark",
                 "Hedmark",
                 "Hordaland",
                 "M\u00F8re og Romsdal",
                 "Nordland",
                 "Oppland",
                 "Oslo",
                 "Rogaland",
                 "Sogn og Fjordane",
                 "Telemark",
                 "Troms",
                 "Tr\u00F8ndelag",
                 "Vest-Agder",
                 "Vestfold",
                 "\u00D8stfold")){
    rmarkdown::render(CONFIG$FILES_RMD_USE_FYLKE,
                      output_file = sprintf("%s.pdf",fylke),
                      output_dir = outputDirDaily,
                      params = list(dev = dev,fylke=fylke))
  }

}
