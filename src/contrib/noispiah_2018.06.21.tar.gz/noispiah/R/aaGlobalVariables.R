#' CONFIG
#' @export CONFIG
CONFIG <- new.env(parent = emptyenv())
CONFIG$FORCE_TESTING <- FALSE
CONFIG$FILES_DATA <- c("AntibiotikadataPrimer.xlsx","InfeksjonsdataPrimer.xlsx")
CONFIG$LATEX_RAW <- c("fhi_nois.latex","fhi.pdf_tex","fhi.pdf")
CONFIG$FILES_RMD_RAW <- c("landsdekkende.Rmd","fylke.Rmd")
CONFIG$FILES_RMD_USE_LANDSDEKKENDE <- ""
CONFIG$FILES_RMD_USE_FYLKE <- ""

#' If folders are setup according to the
#' dashboard philosophy, then this function
#' sets RPROJ
#' @param var a
#' @param val a
#' @export SetConfig
SetConfig <- function(
  var,
  val
){

  CONFIG[[var]] <- val
}
