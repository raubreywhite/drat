library(testthat)
library(RAWmisc)

test_check("RAWmisc")
