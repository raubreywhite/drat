.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: normomo')
  packageStartupMessage('Version 2017.10.27')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
