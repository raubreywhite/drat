.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: momo')
  packageStartupMessage('Version 2017.12.14')
}
