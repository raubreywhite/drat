library(testthat)
library(momo)
library(data.table)

test_check("momo")
