.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: RAWmisc')
  packageStartupMessage('Version 2018.06.12')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
