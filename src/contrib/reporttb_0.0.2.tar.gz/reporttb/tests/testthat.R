library(testthat)
library(reporttb)

test_check("reporttb")
