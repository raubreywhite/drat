context("FormatData")


test_that("Basic Oslo", {

  expect_equal(3,3)
})

