.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: FHI')
  packageStartupMessage('Version 2018.09.24')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
