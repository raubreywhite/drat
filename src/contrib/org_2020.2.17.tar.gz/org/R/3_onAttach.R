.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2019.04.02 at 13:45")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
