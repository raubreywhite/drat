.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: RAWmisc')
  packageStartupMessage('Version 2018.02.04')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
