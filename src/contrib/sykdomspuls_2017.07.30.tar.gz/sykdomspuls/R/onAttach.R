
.onAttach <- function(libname, pkgname) {
  packageStartupMessage('Sykdomspulsen package')
}
