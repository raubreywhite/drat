.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: sykdomspuls')
  packageStartupMessage('Version')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}
