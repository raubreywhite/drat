.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: momo')
  packageStartupMessage('Version 2018.09.14')
}
