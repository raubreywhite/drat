library(testthat)
library(normomo)

test_check("normomo")
