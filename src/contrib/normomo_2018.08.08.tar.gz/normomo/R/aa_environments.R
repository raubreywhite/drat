#' CONFIG
#' @export CONFIG
CONFIG <- new.env(parent = emptyenv())
CONFIG$VALID_FYLKE <- c(1:12,14:15,50,18:20)

