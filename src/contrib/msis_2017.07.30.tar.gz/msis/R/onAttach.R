.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: msis')
  packageStartupMessage('Version 2017.07.30')
  packageStartupMessage('Developed by Beatriz Valcarcel, Norwegian Institute of Public Health')
}
